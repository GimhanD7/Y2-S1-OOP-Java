package paper2019B.Q1;

public interface IMontionTracker {

	abstract void displayLocation();
	
	
}
