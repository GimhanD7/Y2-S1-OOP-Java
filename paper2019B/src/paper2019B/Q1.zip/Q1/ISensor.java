package paper2019B.Q1;

public interface ISensor {
	
	 abstract void on();
	 abstract void off();
	
}
